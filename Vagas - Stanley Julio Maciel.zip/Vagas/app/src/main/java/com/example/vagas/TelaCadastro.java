package com.example.vagas;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

public class TelaCadastro {
    public void Gravar()
     {
         String txtNome = nome.getText().toString();
         String txtCpf = cpf.getText().toString();
         String txtEmail = email.getText().toString();

         SharedPreferences obj = getSharedPreferences(name: "Dados" , Context.MODE_PRIVATE);

         SharedPreferences.Editor edicao = obj.edit();
         edicao.putString(s:"NOME",txtNome);
         edicao.putString(s: "CPF", txtCpf);
         edicao.putString(s: "EMAIL", txtEmail);
         edicao.apply();
         Toast.makeText(getBaseContext(), text "DADOS INSERIDOS COM SUCESSO", Toast.LENGTH_SHORT).show();



     }

     Public void recuperar()
    {
        SharedPreferences objRecupera = getSharedPreferences(name: "Dados",Context.MODE_PRIVATE);
        
    }

}
