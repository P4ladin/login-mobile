package com.example.vagas;

public class TelaVagas {
}
